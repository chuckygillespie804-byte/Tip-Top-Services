
import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import morgan from 'morgan';
import fetch from 'node-fetch';
import { fileURLToPath } from 'url';
import { v4 as uuidv4 } from 'uuid';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Data storage helpers (JSON files with safe fallback to memory)
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = {
  appointments: [],
  quotes: [],
  messages: []
};

const loadFile = (name) => {
  const file = path.join(dataDir, `${name}.json`);
  try {
    if (fs.existsSync(file)) {
      const raw = fs.readFileSync(file, 'utf8');
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error("Failed to load", name, e);
  }
  return [];
};

const saveFile = (name, data) => {
  const file = path.join(dataDir, `${name}.json`);
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error("Failed to save", name, e);
    return false;
  }
};

// Initialize from disk if available
db.appointments = loadFile('appointments');
db.quotes = loadFile('quotes');
db.messages = loadFile('messages');

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'Tip Top Services API', time: new Date().toISOString() });
});

// Create appointment
app.post('/api/appointments', (req, res) => {
  const { name, phone, email, service, date, notes } = req.body || {};
  if (!name || !phone || !service || !date) {
    return res.status(400).json({ error: 'Missing required fields: name, phone, service, date' });
  }
  const item = { id: uuidv4(), name, phone, email: email || '', service, date, notes: notes || '', createdAt: new Date().toISOString() };
  db.appointments.push(item);
  saveFile('appointments', db.appointments);
  res.status(201).json({ ok: true, appointment: item });
});

// Create quote request
app.post('/api/quotes', (req, res) => {
  const { name, phone, email, projectType, acreage, address, details } = req.body || {};
  if (!name || !phone || !projectType) {
    return res.status(400).json({ error: 'Missing required fields: name, phone, projectType' });
  }
  const item = { id: uuidv4(), name, phone, email: email || '', projectType, acreage: acreage || '', address: address || '', details: details || '', createdAt: new Date().toISOString() };
  db.quotes.push(item);
  saveFile('quotes', db.quotes);
  res.status(201).json({ ok: true, quote: item });
});

// Customer message (support)
app.post('/api/messages', (req, res) => {
  const { name, email, subject, message } = req.body || {};
  if (!name || !message) {
    return res.status(400).json({ error: 'Missing required fields: name, message' });
  }
  const item = { id: uuidv4(), name, email: email || '', subject: subject || '', message, createdAt: new Date().toISOString() };
  db.messages.push(item);
  saveFile('messages', db.messages);
  res.status(201).json({ ok: true, message: item });
});

// Live sports scores using ESPN public endpoints
// Supported leagues: nfl, nba, mlb, nhl, ncaaf
const LEAGUE_MAP = {
  nfl: 'football/nfl',
  nba: 'basketball/nba',
  mlb: 'baseball/mlb',
  nhl: 'hockey/nhl',
  ncaaf: 'football/college-football'
};

app.get('/api/scores', async (req, res) => {
  const league = (req.query.league || 'nfl').toLowerCase();
  const espnPath = LEAGUE_MAP[league];
  if (!espnPath) {
    return res.status(400).json({ error: 'Unsupported league. Try nfl, nba, mlb, nhl, ncaaf.' });
  }
  const url = `https://site.api.espn.com/apis/v2/sports/${espnPath}/scoreboard`;
  try {
    const r = await fetch(url);
    if (!r.ok) throw new Error(`ESPN responded with ${r.status}`);
    const data = await r.json();
    // Normalize a compact list of games
    const events = (data.events || []).map(ev => ({
      id: ev.id,
      name: ev.name,
      date: ev.date,
      status: ev.status?.type?.shortDetail || ev.status?.type?.description || '',
      competitions: (ev.competitions || []).map(c => ({
        venue: c.venue?.fullName || '',
        competitors: (c.competitors || []).map(t => ({
          id: t.id,
          team: t.team?.displayName || t.team?.name || '',
          abbreviation: t.team?.abbreviation || '',
          score: t.score,
          homeAway: t.homeAway,
          record: t.records && t.records[0] ? t.records[0].summary : ''
        }))
      }))
    }));
    res.json({ ok: true, league, count: events.length, events });
  } catch (e) {
    res.status(500).json({ error: 'Failed to fetch scores', detail: e.message });
  }
});

// Serve the frontend if deployed together
const frontendDir = path.join(__dirname, '..', 'frontend');
app.use(express.static(frontendDir));
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Tip Top Services server running on http://localhost:${PORT}`);
});

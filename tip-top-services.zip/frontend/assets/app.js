
const $ = (sel) => document.querySelector(sel);

document.addEventListener('DOMContentLoaded', () => {
  // Footer year
  $('#year').textContent = new Date().getFullYear();

  // Appointment form
  const appointmentForm = $('#appointmentForm');
  appointmentForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(appointmentForm);
    const payload = Object.fromEntries(form.entries());
    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const out = await res.json();
    $('#appointmentStatus').textContent = out.ok ? 'Appointment submitted! We will contact you shortly.' : (out.error || 'Something went wrong.');
    if (out.ok) appointmentForm.reset();
  });

  // Quote form
  const quoteForm = $('#quoteForm');
  quoteForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(quoteForm);
    const payload = Object.fromEntries(form.entries());
    const res = await fetch('/api/quotes', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const out = await res.json();
    $('#quoteStatus').textContent = out.ok ? 'Quote request received! We will reach out with pricing.' : (out.error || 'Something went wrong.');
    if (out.ok) quoteForm.reset();
  });

  // Support form
  const supportForm = $('#supportForm');
  supportForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(supportForm);
    const payload = Object.fromEntries(form.entries());
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const out = await res.json();
    $('#supportStatus').textContent = out.ok ? 'Message sent! Our team will reply ASAP.' : (out.error || 'Something went wrong.');
    if (out.ok) supportForm.reset();
  });

  // Scores
  const leagueSelect = $('#league');
  const scoresList = $('#scoresList');
  const refresh = $('#refreshScores');

  async function loadScores() {
    scoresList.textContent = 'Loading scores…';
    const league = leagueSelect.value;
    try {
      const res = await fetch(`/api/scores?league=${encodeURIComponent(league)}`);
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'Failed');
      renderScores(data.events);
    } catch (e) {
      scoresList.textContent = 'Unable to load scores right now.';
      console.error(e);
    }
  }

  function renderScores(events) {
    if (!events || events.length === 0) {
      scoresList.textContent = 'No games found right now.';
      return;
    }
    scoresList.innerHTML = '';
    events.slice(0, 20).forEach(ev => {
      const comp = ev.competitions && ev.competitions[0];
      if (!comp) return;
      const [a,b] = comp.competitors || [];
      const home = a?.homeAway === 'home' ? a : b;
      const away = a?.homeAway === 'home' ? b : a;
      const card = document.createElement('div');
      card.className = 'score-card';
      card.innerHTML = `
        <div class="row"><div>${ev.status}</div><div>${new Date(ev.date).toLocaleString()}</div></div>
        <div class="row">
          <div class="score-team"><span class="abbr">${away?.abbreviation || ''}</span> <strong>${away?.team || ''}</strong></div>
          <div>${away?.score ?? '-'}</div>
        </div>
        <div class="row">
          <div class="score-team"><span class="abbr">${home?.abbreviation || ''}</span> <strong>${home?.team || ''}</strong></div>
          <div>${home?.score ?? '-'}</div>
        </div>
      `;
      scoresList.appendChild(card);
    });
  }

  refresh.addEventListener('click', loadScores);
  leagueSelect.addEventListener('change', loadScores);
  loadScores();
  setInterval(loadScores, 60 * 1000); // refresh every minute
});

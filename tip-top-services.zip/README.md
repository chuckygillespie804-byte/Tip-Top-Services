
# Tip Top Services — Dynamic Website

A professional, dynamic website for **Tip Top Services** with:
- Black, yellow, and white color scheme
- Services: Land clearing, dirt add/remove
- Features: Appointments, quotes, customer service, sustainability ideas
- Live sports scores (NFL/NBA/MLB/NHL/NCAAF) fetched from ESPN public scoreboards

## Quick Start (Local)

1. Install Node.js 18+
2. Open a terminal in `backend/` and run:

```bash
npm install
npm start
```

3. Visit http://localhost:3000

> The server serves the frontend and handles API routes.

## Deploy Options

- **Render / Railway / Fly.io / Heroku**: Create a new Node app, point to the `backend/` folder, and set the start command to `node server.js`.
- **Vercel**: This project is a single Node server (not serverless). You can convert to serverless functions if you prefer, but the simplest path is Render/Railway.
- **Google Business Profile**: You can add your website URL on your profile. (Google retired the old auto-generated GBP websites.) Host this app (e.g., on Render) and paste that URL into your Google Business Profile.

## API Endpoints

- `POST /api/appointments` → { name, phone, email?, service, date, notes? }
- `POST /api/quotes` → { name, phone, email?, projectType, acreage?, address?, details? }
- `POST /api/messages` → { name, email?, subject?, message }
- `GET /api/scores?league=nfl|nba|mlb|nhl|ncaaf` → Fetches live/ongoing/recent games

Data is written to JSON files under `backend/data/`. On read-only hosts, it will still run but persistence may reset on redeploy. For production persistence, consider a lightweight database (SQLite or a hosted Postgres).

## Customization

- Edit `frontend/index.html` for content.
- Edit `frontend/assets/styles.css` for brand styling.
- Edit `frontend/assets/app.js` for UI logic.
- Add your business phone, email, and address directly in the HTML/footer.

## SEO Tips

- Set a custom domain (e.g., tiptopservices.com) with your host.
- Add your domain to your Google Business Profile under “Website”.
- Include your service area and keywords in headings and body copy.
